console.log("Welcome To Majalengka")

alert("Selamat Datang, Happy Reading Kawan :)!!")